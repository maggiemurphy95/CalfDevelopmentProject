#TE Script 1 - Load data and packages 
#load packages####
library(btools)
library(cowplot)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(metagenomeSeq)
library(metagMisc)
library(pairwiseAdonis)
library(phyloseq)
library(picante)
library(randomcoloR)
library(scales)
library(stringr)
library(vegan)
library(microbiome)
library(ggdendro)
library(UpSetR)
library(DAtest)
library(ANCOMBC)
library(DT)
library(ggrepel)
library(tidyr)

# setwd####
setwd("/Volumes/USB20FD/PhD Projects. Meetings. Protocols/Developmental Calf.pooling/Individual Calf/Code for Pub/TE/")

# import data ####
AMRdata <- import_biom("data/SamDedup_AMR_analytic_matrix_phyloseq.biom")
#MM: Make sure all of your titles are lowercase
map_file_TE <- import_qiime_sample_data("data/metadatafilenewTE.txt")#Same as 16S but with TE labels 

#merge 
data_TE <- merge_phyloseq(AMRdata, map_file_TE)

# check the names of our ranks
rank_names(data_TE) # "Rank1" - "Rank6" not ideal, lets change em
colnames(tax_table(data_TE)) <- c("Type","Class","Mechanism","Group","Gene","SNP")
rank_names(data_TE) # beauty, now they are named properly

#SNP stuff, did not do SNP ratios 
data_SNPconfirm <- subset_taxa(data_TE, SNP=="yes", T) # error in dimnames length - the yes was lowercase 
data_noSNP <- subset_taxa(data_TE, SNP=="no") # 

# Taking Sequins out
data_noSNP <- subset_taxa(data_noSNP, Class!= "sequins")

#Calf data object creation
datacalf_noSNP <- subset_samples(data_noSNP, sample_type=="Calf" & SampleID!="IndivTE_30")
