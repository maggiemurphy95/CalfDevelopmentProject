#TE Script 3 - Alpha-Diversity and UpsetPlots 
#############################################################################################
##############################         ALPHA DIVERSITY         ##############################
#############################################################################################
#############################################################################################
#Estimate all the alpha-div indices at the GROUP level
alpha_div_TE_group <- estimate_richness(data_noSNP_group, measures = c("Observed","Shannon","Simpson","InvSimpson"))
alpha_div_TE_group #Warning: The data you provided does not have any singletons, this is is highly suspicious. Results of richness estimates are probably unreliable, or wrong, if you have already trimmed low-abundance taxa from the data. We recommend that you find the untrimmed data and retry. 
alpha_div_TE_group.df <- as(sample_data(data_noSNP_group), "data.frame")
alpha_div_meta_group_TE <- cbind(alpha_div_TE_group, alpha_div_TE_group.df) #combining alpha div with metadata
alpha_div_meta_group_TE

#########Richness and Diversity###############
#at group level
calf_group_alpha_div_TE<- alpha_div_meta_group_TE[which(alpha_div_meta_group_TE$sample_type=="Calf"),]
calf_group_alpha_div_TE

#Richness
#Showing the TE Richness at the group level with a boxplot 
terich_group<-ggplot(alpha_div_meta_group_TE, aes(x=weaning, y= Observed, fill= weaning, color=weaning)) + 
  theme_bw() +
  geom_boxplot(alpha= 0.5, size= 0.75)+
  geom_point()+
  labs(y= "Richness", x= "") +
  scale_fill_manual(values=c(cohort_palette))+
  scale_color_manual(values=c(cohort_palette))+
  scale_x_discrete(limits=c("Pre1","Pre2","Pre3","Post1","Post2")) +
  scale_y_continuous(expand = c(0,0,0.1,0)) +
  theme(legend.position = "none",
        plot.margin = unit(c(0.75,0.75,0.75,0.75),"cm"),
        panel.border = element_rect(colour = "black", size = 1.7),
        axis.ticks = element_line(size = 1, colour = "black"),
        plot.title = element_text(size = 40),
        axis.title.y = element_text(size = 40, vjust = 2.5),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size = 24, colour = "black"),
        axis.title.x = element_blank(),
        panel.grid.major.x = element_blank())
terich_group
ggsave("output_data/TERichness_group.png",terich_group)

##Diversity
#Showing the TE Diversity at the group level and matching the 16S work with a boxplot 
tediversity_group<-ggplot(alpha_div_meta_group_TE, aes(x=weaning, y= Shannon, fill= weaning, color=weaning)) + 
  theme_bw() +
  geom_boxplot(alpha= 0.5, size= 0.75)+
  geom_point()+
  labs(y= "Shannon's Diversity", x= "") +
  scale_fill_manual(values=c(cohort_palette))+
  scale_color_manual(values=c(cohort_palette))+
  scale_x_discrete(limits=c("Pre1","Pre2","Pre3","Post1","Post2")) +
  scale_y_continuous(expand = c(0,0,0.1,0)) +
  theme(legend.position = "none",
        plot.margin = unit(c(0.75,0.75,0.75,0.75),"cm"),
        panel.border = element_rect(colour = "black", size = 1.7),
        axis.ticks = element_line(size = 1, colour = "black"),
        plot.title = element_text(size = 40),
        axis.title.y = element_text(size = 40, vjust = 2.5),
        axis.text.x = element_blank(),
        axis.text.y = element_text(size = 24, colour = "black"),
        axis.title.x = element_blank(),
        panel.grid.major.x = element_blank())
tediversity_group
ggsave("output_data/TEDiversity_group.png",tediversity_group)

#Stats on the TE work at the group level 
pairwise.wilcox.test(alpha_div_meta_group_TE$Observed, alpha_div_meta_group_TE$weaning, p.adjust.method = "BH")
pairwise.wilcox.test(alpha_div_meta_group_TE$Shannon, alpha_div_meta_group_TE$weaning, p.adjust.method = "BH")

#####################UPSET PLOTS ON SHARED ARGs IN GROUPS/HOUSING##############
#upload these packages, but they conflict with phyloseq later, so must detach at the end  
library(UpSetR)
library("MicrobiotaProcess")

#####By cohort
#make a color palette, because for some reason UpsetPlot doesn't want to work with the original palette 
upsetcolorcohort <- c("goldenrod2","#ae5a41", "#559e83","#1b85b8","honeydew4")

#Do some filtering
#pre-filtering before making the upset plot - remove singletons and doubletons
data.preDA.te <- preDA(data_noSNP_group, min.samples = 2) #67 features grouped as "others"
upset_DA_te <- get_upset(data.preDA.te, factorNames="weaning")

#Then make a Regular upset plot
#make a way to save the plot
png("output_data/teupsetplot.png", width = 1200, height = 800)
upset(upset_DA_te, sets=c("Post2","Post1","Pre3","Pre2","Pre1"
),
sets.bar.color = c(upsetcolorcohort),
keep.order=TRUE, #empty.intersections = "on",
order.by = "freq",
text.scale = c(3, 3, 2, 2, 3, 3))

dev.off()

#Now detach so not to conflict with Phyloseq later
detach("package:MicrobiotaProcess", unload = TRUE)
detach("package:UpSetR", unload = TRUE)#detach this package now so it doesn't impact phyloseq later
