#TE Script 5 - Dendrogram and Relative Abundance plots####
#source betadiv parts of code here - like just my distance object

### clustering on BrayCurtis####
data.indivtehclust.group <- hclust(calf_beta_div_group_TE.dist, method = "ward.D2")
plot(data.indivtehclust.group)
data.dendro.indivte.group <- as.dendrogram(data.indivtehclust.group)
data.dendro.indivcalfte.group <- dendro_data(data.dendro.indivte.group, type = "rectangle")
data.dendro.indivcalfte.group

#Dendrogram ####
#merge your columns now and create a metadata file
calfgroup.metadata.dendro <- as_tibble(calf_beta_div_group_TE.css@sam_data)
data.dendro.indivcalfte.group$labels <- data.dendro.indivcalfte.group$labels %>%
  left_join(calfgroup.metadata.dendro, by = c("label"="SampleID"))
data.dendro.indivcalfte.group

#Ward's Clades
wardste<-ggplot(data.dendro.indivcalfte.group$segments) + theme_bw() +
  labs(y= "Ward's Distance") +
  geom_segment(aes(x=x,y=y,xend=xend,yend=yend), size =.5, lineend = "round", linejoin = "round") +
  geom_point(data = data.dendro.indivcalfte.group$labels, aes(x,y, color = weaning), 
             size =9, position = position_nudge(y=-.08), shape = 15) +
  geom_text(data = data.dendro.indivcalfte.group$labels,
            aes(x, y, label = age),  # replace label_variable with your actual label variable
            size = 4, position = position_nudge(y = -0.08)) +
  scale_colour_manual(values = cohort_palette) +
  scale_x_discrete(limits=c("Pre1","Pre2","Pre3","Post1","Post2")) +
  coord_cartesian(xlim = c(1, length(unique(data.dendro.indivcalfte.group$labels$x)) + 1), clip = "off") +
  theme(legend.position = "none",
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.text.x = element_blank(),
        axis.title.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line.y = element_line(size = 0.75),
        axis.title.y = element_text(size = 36),
        axis.text.y = element_text(size = 20, colour = "black"))
wardste
ggsave("output_data/wards_te.png",wardste)

###Stacked bar plot for under dendrogram
#create an RA object that can be agglomerated at the class level and to be used for all RA plots
rel_abund_calf_group_TE <- transform_sample_counts(calf_beta_div_group_TE.css, function(x) {x/sum(x)}*100)
rel_abund_calf_group_TE
plot(sort(sample_sums(rel_abund_calf_group_TE), TRUE), type = "h", ylab = "reads", xlab= "samples") #Good to go

#class level object creation
rel_abund_calf_class <- tax_glom(rel_abund_calf_group_TE, taxrank = "Class")
ra_class_calf_melt <- psmelt(rel_abund_calf_class)

#How many Classes
length(unique(ra_class_calf_melt$Class))#43
#create a palatte for the classes 
Classcolors <- distinctColorPalette(43)
#Don't run again if you like it!

#Make sure that the barplot in the correct order 
dendrosampleorder<-data.dendro.indivcalfte.group$labels$label

dendro_ra_te<-ggplot(ra_class_calf_melt, aes(x= Sample, y= Abundance, fill = Class)) +
  theme_bw() +
  labs(y= "Relative Abundance (%)") +
  geom_bar(stat = "summary", colour = "black") +
  scale_fill_manual(values = Classcolors) +
  scale_x_discrete(limits = dendrosampleorder) +
  theme(legend.position = "none",
    panel.border = element_blank(),
    panel.grid = element_blank(),
    axis.line.y = element_line(color = "black", size = 0.75),
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.ticks.y = element_line(size = 0.75, lineend = "square", colour = "black"),
    axis.title.y = element_text(size = 36),
    axis.text.y = element_text(size = 20, colour = "black"))
dendro_ra_te
ggsave("output_data/ra_dendro_te.png",dendro_ra_te)

# calculate percentages across all classes counts for calves- if you want to report something
calf_class_abund_perc <- ra_class_calf_melt %>%
  dplyr::group_by(weaning, Class) %>%
  dplyr::summarize(mean_class_calf_perc = mean(Abundance)) %>%
  arrange(-mean_class_calf_perc)
write.csv(calf_class_abund_perc, "output_data/calf_class_abund_perc.csv")

#############################################################################################
############################         RELATIVE ABUNDANCE PLOTS   #############################
#############################################################################################
#############################################################################################
#Use the rel_abund_calf_TE object from up above
##################################################Mechanism Graphs with Classes#################################################
#For the mechanism plots that show changes in the classes, agglomerate at the mechanism level 
rel_abund_calf_mechanism <- tax_glom(rel_abund_calf_group_TE, taxrank = "Mechanism")
ra_mechanism_calf_melt <- psmelt(rel_abund_calf_mechanism)

#######################Tetracyclines
TetraRAClass <- subset_taxa(rel_abund_calf_class, Class=="Tetracyclines") %>%
  psmelt()

tetraRA_mech<- subset_taxa(rel_abund_calf_mechanism, Class=="Tetracyclines")%>%
  psmelt()

#Tetracyclines graph 
tetra_palette <- distinctColorPalette(3)

tetraRA_mech_plot<-ggplot(tetraRA_mech, aes(x= weaning, y= Abundance)) +
  theme_bw() + coord_flip() +
  labs(y= "Relative Abundance (%)", title = "Tetracyclines") +
  geom_bar(aes(fill= Mechanism), stat = "summary", colour = "black", size = 0.75) +
  geom_errorbar(data=TetraRAClass, aes(x=weaning, y=Abundance), stat = "summary", width= 0.4, size= 0.75)+
  scale_fill_manual(values = tetra_palette) +
  scale_y_continuous(limits = c(0,75), expand = c(0.001,0,-0.1,0)) +
  scale_x_discrete(limits = c("Post2","Post1","Pre3","Pre2","Pre1"), labels = c("Post2","Post1","Pre3","Pre2","Pre1")) +
  theme(legend.position = "none",
    plot.margin = unit(c(1,1,1,1),"lines"),
    panel.border = element_rect(size = 1.5, colour = "black"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.title = element_text(size = 40),
    axis.title.x = element_text(size = 36, vjust = -1),
    axis.text.x = element_text(size = 22, colour = "black"),
    axis.title.y = element_blank(),
    axis.text.y = element_text(colour = "black", size = 32),
    axis.ticks.x = element_line(size = 0.9, colour = "black"),
    axis.ticks.y = element_line(size = 0.9, colour = "black"))
tetraRA_mech_plot
ggsave("output_data/tetra_mechanismplot.png",tetraRA_mech_plot)

##########calculate percentages and se and sd on Tetra Mechanisms###################
# calculate percentages across all order counts for calves
calf_tetramech_perc <- tetraRA_mech %>%
  dplyr::group_by(weaning, Mechanism) %>%
  dplyr::summarize(mean_tetra_calf_perc = mean(Abundance),sd_order_calf_perc=sd(Abundance), se_order_calf_perc = (sd(Abundance)/sqrt(length(Abundance)))) %>%
  arrange(-mean_tetra_calf_perc)
write.csv(calf_tetramech_perc, "output_data/calf_tetra_abund_perc.csv")

################################MLS
MLSRAClass <- subset_taxa(rel_abund_calf_class, Class=="MLS") %>%
  psmelt()

MLSRA_mech<- subset_taxa(rel_abund_calf_mechanism, Class=="MLS")%>%
  psmelt()

#MLS graph
MLS_palette <- distinctColorPalette(6)
MLS_RAplot<-ggplot(MLSRA_mech, aes(x= weaning, y= Abundance)) +
  theme_bw() + coord_flip() +
  labs(y= "Relative Abundance (%)", title = "MLS") +
  geom_bar(aes(fill= Mechanism), stat = "summary", colour = "black", size = 0.75) +
  geom_errorbar(data=MLSRAClass, aes(x=weaning, y=Abundance), stat = "summary", width= 0.4, size= 0.75)+
  scale_fill_manual(values = MLS_palette) +
  scale_y_continuous(limits = c(0,20), expand = c(0.001,0,-0.1,0)) +
  scale_x_discrete(limits = c("Post2","Post1","Pre3","Pre2","Pre1"), labels = c("Post2","Post1","Pre3","Pre2","Pre1")) +
  theme(legend.position = "none",
    plot.margin = unit(c(1,1,1,1),"lines"),
    panel.border = element_rect(size = 1.5, colour = "black"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.title = element_text(size = 40),
    axis.title.x = element_text(size = 36, vjust = -1),
    axis.text.x = element_text(size = 22, colour = "black"),
    axis.title.y = element_blank(),
    axis.text.y = element_text(colour = "black", size = 32),
    axis.ticks.x = element_line(size = 0.9, colour = "black"),
    axis.ticks.y = element_line(size = 0.9, colour = "black"))
MLS_RAplot
ggsave("output_data/mls_mechanismplot.png",MLS_RAplot)

# calculate percentages and se across all DB counts for calves
calf_mls_perc <- MLSRA_mech %>%
  dplyr::group_by(weaning, Mechanism) %>%
  dplyr::summarize(mean_mls_calf_perc = mean(Abundance), se_order_calf_perc = (sd(Abundance)/sqrt(length(Abundance)))) %>%
  arrange(-mean_mls_calf_perc)
write.csv(calf_mls_perc, "output_data/calf_mls_abund_perc.csv")

###############Drug and biocide
BioRAClass <- subset_taxa(rel_abund_calf_class, Class=="Drug_and_biocide_resistance") %>%
  psmelt()

BioRA_mech<- subset_taxa(rel_abund_calf_mechanism, Class=="Drug_and_biocide_resistance")%>%
  psmelt()

#Drug&Bioicde graph
db_palette <- distinctColorPalette(9)

DandB_RAplot<-ggplot(BioRA_mech, aes(x= weaning, y= Abundance)) +
  theme_bw() + coord_flip() +
  labs(y= "Relative Abundance (%)", title = "Drug & Bioicide Resistance") +
  geom_bar(aes(fill= Mechanism), stat = "summary", colour = "black", size = 0.75) +
  geom_errorbar(data=BioRAClass, aes(x=weaning, y=Abundance), stat = "summary", width= 0.4, size= 0.75)+
  scale_fill_manual(values = db_palette) +
  scale_y_continuous(limits = c(0,25), expand = c(0.001,0,-0.1,0)) +
  scale_x_discrete(limits = c("Post2","Post1","Pre3","Pre2","Pre1"), labels = c("Post2","Post1","Pre3","Pre2","Pre1")) +
  theme(legend.position = "none",
    plot.margin = unit(c(1,1,1,1),"lines"),
    panel.border = element_rect(size = 1.5, colour = "black"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.title = element_text(size = 40),
    axis.title.x = element_text(size = 36, vjust = -1),
    axis.text.x = element_text(size = 22, colour = "black"),
    axis.title.y = element_blank(),
    axis.text.y = element_text(colour = "black", size = 32),
    axis.ticks.x = element_line(size = 0.9, colour = "black"),
    axis.ticks.y = element_line(size = 0.9, colour = "black"))
DandB_RAplot
ggsave("output_data/drugandbiocide_mechanismplot.png",DandB_RAplot)

# calculate percentages across all DB counts for calves
calf_DB_perc <- BioRA_mech %>%
  dplyr::group_by(weaning, Mechanism) %>%
  dplyr::summarize(mean_DB_calf_perc = mean(Abundance), se_order_calf_perc = (sd(Abundance)/sqrt(length(Abundance)))) %>%
  arrange(-mean_DB_calf_perc)
write.csv(calf_DB_perc, "output_data/calf_DB_abund_perc.csv")

#########################Multi-metal resistance
MultiRAClass <- subset_taxa(rel_abund_calf_class, Class=="Multi-metal_resistance") %>%
  psmelt()

MultiRA_mech<- subset_taxa(rel_abund_calf_mechanism, Class=="Multi-metal_resistance")%>%
  psmelt()

#MultiMetal graph to match 16S from Lee
mm_palette <- distinctColorPalette(5)

multimetal_RAplot<-ggplot(MultiRA_mech, aes(x= weaning, y= Abundance)) +
  theme_bw() + coord_flip() +
  labs(y= "Relative Abundance (%)", title = "Multi-metal Resistance") +
  geom_bar(aes(fill= Mechanism), stat = "summary", colour = "black", size = 0.75) +
  geom_errorbar(data=MultiRAClass, aes(x=weaning, y=Abundance), stat = "summary", width= 0.4, size= 0.75)+
  scale_fill_manual(values = db_palette) +
  scale_y_continuous(limits = c(0,20), expand = c(0.001,0,-0.1,0)) +
  scale_x_discrete(limits = c("Post2","Post1","Pre3","Pre2","Pre1"), labels = c("Post2","Post1","Pre3","Pre2","Pre1")) +
  theme(legend.position = "none",
    plot.margin = unit(c(1,1,1,1),"lines"),
    panel.border = element_rect(size = 1.5, colour = "black"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.title = element_text(size = 40),
    axis.title.x = element_text(size = 36, vjust = -1),
    axis.text.x = element_text(size = 22, colour = "black"),
    axis.title.y = element_blank(),
    axis.text.y = element_text(colour = "black", size = 32),
    axis.ticks.x = element_line(size = 0.9, colour = "black"),
    axis.ticks.y = element_line(size = 0.9, colour = "black"))
multimetal_RAplot
ggsave("output_data/multimetal_mechanismplot.png",multimetal_RAplot)

# calculate percentages and se across all DB counts for calves
calf_multi_perc <- MultiRA_mech %>%
  dplyr::group_by(weaning, Mechanism) %>%
  dplyr::summarize(mean_multi_calf_perc = mean(Abundance), se_order_calf_perc = (sd(Abundance)/sqrt(length(Abundance)))) %>%
  arrange(-mean_multi_calf_perc)
write.csv(calf_multi_perc, "output_data/calf_multi_abund_perc.csv")
