#TE Script 2 - Summary stats, QC checks, and rarefaction curve 
#set working directory 
setwd("/Volumes/USB20FD/PhD Projects. Meetings. Protocols/Developmental Calf.pooling/Individual Calf/Code for Pub/TE")

#load the packages and the data
source("TEScript1_LoadData.R", echo=TRUE)

# some QC checks
min(sample_sums(datacalf_noSNP)) # 314043 lowest AMR count matrix 
max(sample_sums(datacalf_noSNP)) # 1321298 highest - was 1.7 mil but we took #30 out
sort(sample_sums(datacalf_noSNP)) #Don't need to get rid of anything, no big jumps in numbers
median(sample_sums(datacalf_noSNP)) #587637.5
mean(sample_sums(datacalf_noSNP)) #665805.8

#Create an object that is NOT normalized, but at the group level, not the counts level, since we cannot trust the counts level 
data_noSNP_group <- tax_glom(datacalf_noSNP, taxrank = "Group") #486 taxa and 46 samples

#Write CSV to do % AMR hits
Calf_AMRHits<- sample_sums(data_noSNP_group)
write.csv(Calf_AMRHits, "output_data/IndivCalf_AMRHits.csv")

# TE Rarefaction Curve -------------------------------------------------------
#subset ASV table
amr_matrix <- otu_table(datacalf_noSNP)
amr_matrix <- as.matrix(amr_matrix)

#Rarefaction curve function - if this has been run already from the 16S work, disregard
calculate_rarefaction_curves <- function(otu_matrix, measures, depths) {
  require('plyr') # ldply
  require('reshape2') # melt
  
  estimate_rarified_richness <- function(otu_matrix, measures, depth) {
    if(max(sample_sums(otu_matrix)) < depth) return()
    otu_matrix <- prune_samples(sample_sums(otu_matrix) >= depth, otu_matrix)
    
    rarified_otu_matrix <- rarefy_even_depth(otu_matrix, depth, verbose = FALSE)
    
    alpha_diversity <- estimate_richness(rarified_otu_matrix, measures = measures)
    
    # as.matrix forces the use of melt.array, which includes the Sample names (rownames)
    molten_alpha_diversity <- melt(as.matrix(alpha_diversity), varnames = c('Sample', 'Measure'), value.name = 'Alpha_diversity')
    
    molten_alpha_diversity
  }
  
  names(depths) <- depths # this enables automatic addition of the Depth to the output by ldply
  rarefaction_curve_data <- ldply(depths, estimate_rarified_richness, otu_matrix = otu_matrix, measures = measures, .id = 'Depth', .progress = ifelse(interactive(), 'text', 'none'))
  
  # convert Depth from factor to numeric
  rarefaction_curve_data$Depth <- as.numeric(levels(rarefaction_curve_data$Depth))[rarefaction_curve_data$Depth]
  
  rarefaction_curve_data
}

#calculate observed and Shannon at different depths (caps at 1 mil) ####
amr_rarefaction_curve_data <- calculate_rarefaction_curves(amr_matrix, c('Observed'), rep(c(1, 10, 100, 1000, 1:100 * 10000), each = 10))
summary(amr_rarefaction_curve_data)

amr_rarefaction_curve_data_summary <- ddply(amr_rarefaction_curve_data, c('Depth', 'Sample', 'Measure'), summarise, Alpha_diversity_mean = mean(Alpha_diversity), Alpha_diversity_sd = sd(Alpha_diversity))

amr_rarefaction_curve_data_summary_verbose <- merge(amr_rarefaction_curve_data_summary,data.frame(sample_data(datacalf_noSNP)), by.x = 'Sample', by.y = 'row.names')
#The stupid sampleID's dont match so you will have to make them different 
#amrrarefaction_foals<-data.frame(sample_data(datafoal_noSNP))

#Okay back to your regularly scheduled programming
View(amr_rarefaction_curve_data_summary_verbose)

# Create the paired plot
#Create the cohort palette
cohort_palette <- c("Pre3"="#559e83","Pre1"="#5a5255","Pre2"="#1b85b8","Post1"="#ae5a41","Post2"="#c3cb71")

# This is the corrected and enhanced version of your plot
rarefactionte <- ggplot(
  data = amr_rarefaction_curve_data_summary_verbose,
  mapping = aes(
    x = Depth,
    y = Alpha_diversity_mean,
    ymin = Alpha_diversity_mean - Alpha_diversity_sd,
    ymax = Alpha_diversity_mean + Alpha_diversity_sd,
    colour = weaning,
    group = Sample
  )
) +
  geom_line(size = 1) +  # Make lines thicker
  scale_x_continuous(
    breaks = c(
      seq(0, 300000, by = 50000),
      seq(400000, 1000000, by = 100000)
    ),
    labels = comma
    #breaks = seq(0, max(amr_rarefaction_curve_data_summary_verbose$Depth), by = 100000),
    #labels = comma
  ) +
  facet_wrap(
    facets = ~ Measure,
    scales = 'free_y'
  ) +
  scale_colour_manual(values = cohort_palette) +
  theme_bw() +
  labs(
    y = "Observed Richness",
    x = "Total ARGs Classified per Sample",
    title = "Sequencing Depth by Age Cohort"
  ) +
  theme(
    legend.position = "none",
    plot.margin = unit(c(0.75, 0.75, 0.75, 0.75), "cm"),
    panel.border = element_rect(colour = "black", size = 1.7),
    axis.ticks = element_line(size = 1, colour = "black"),
    plot.title = element_text(size = 30),
    axis.title.y = element_text(size = 24, vjust = 1.5),
    axis.text.x = element_text(size = 24, colour = "black", angle=45, hjust=1),
    axis.text.y = element_text(size = 24, colour = "black"),
    axis.title.x = element_text(size = 24),
    panel.grid.major.x = element_blank(),
    panel.background = element_blank(),  # removes any remaining gray fill
    strip.background = element_blank(),   # removes gray bar
    strip.text = element_blank()
  )
rarefactionte
ggsave("output_data/rarefactioncurvete.png",rarefactionte)

#Paul's TE rarefaction curve ask 
#Import the rarefaction counts and then bring these together 
terarefaction_counts <- read_tsv("data/rarefaction_Raw_counts.txt")

#calculate observed and Shannon at different depths (caps at 1 mil) ####
amr_rarefaction_curve_data <- calculate_rarefaction_curves(amr_matrix, c('Observed'), rep(c(1, 10, 100, 1000, 1:100 * 10000), each = 10))
summary(amr_rarefaction_curve_data)

amr_rarefaction_curve_data_summary <- ddply(amr_rarefaction_curve_data, c('Depth', 'Sample', 'Measure'), summarise, Alpha_diversity_mean = mean(Alpha_diversity), Alpha_diversity_sd = sd(Alpha_diversity))

amr_rarefaction_curve_data_summary_verbose <- merge(amr_rarefaction_curve_data_summary,data.frame(sample_data(datacalf_noSNP)), by.x = 'Sample', by.y = 'row.names')
#The stupid sampleID's dont match so you will have to make them different 
#amrrarefaction_foals<-data.frame(sample_data(datafoal_noSNP))
#See if you can merge the rare counts and this together
# If merge is needed for additional metadata (e.g., 'weaning'), do:
merged_rarefaction <- left_join(terarefaction_counts, amr_rarefaction_curve_data_summary_verbose, by = "Sample")

#Figure out the raw reads by multiplying subsample percent by the nonhost reads 
merged_rarefaction <- merged_rarefaction %>%
  mutate(estimated_read_depth = (SubsamplePercent / 100) * Nonhost)

#Okay back to your regularly scheduled programming
View(amr_rarefaction_curve_data_summary_verbose)
View(merged_rarefaction)

# Create the paired plot
#Create the cohort palette
cohort_palette <- c("Pre3"="#559e83","Pre1"="#5a5255","Pre2"="#1b85b8","Post1"="#ae5a41","Post2"="#c3cb71")

# This is the corrected and enhanced version of your plot
new_rarefactionte <- ggplot(
  data = merged_rarefaction,
  mapping = aes(
    x = estimated_read_depth,
    y = Alpha_diversity_mean,
    ymin = Alpha_diversity_mean - Alpha_diversity_sd,
    ymax = Alpha_diversity_mean + Alpha_diversity_sd,
    colour = weaning,
    group = Sample
  )
) +
  geom_line(size = 1) +  # Make lines thicker
  scale_x_continuous(
    breaks = c(
      seq(0, 300000, by = 50000),
      seq(400000, 1000000, by = 100000)
    ),
    labels = comma
    #breaks = seq(0, max(amr_rarefaction_curve_data_summary_verbose$Depth), by = 100000),
    #labels = comma
  ) +
  facet_wrap(
    facets = ~ Measure,
    scales = 'free_y'
  ) +
  scale_colour_manual(values = cohort_palette) +
  theme_bw() +
  labs(
    y = "Observed Richness",
    x = "Subsampled Percent"
  ) +
  theme(
    legend.position = "none",
    plot.margin = unit(c(0.75, 0.75, 0.75, 0.75), "cm"),
    panel.border = element_rect(colour = "black", size = 1.7),
    axis.ticks = element_line(size = 1, colour = "black"),
    plot.title = element_text(size = 30),
    axis.title.y = element_text(size = 24, vjust = 1.5),
    axis.text.x = element_text(size = 24, colour = "black", angle=45, hjust=1),
    axis.text.y = element_text(size = 24, colour = "black"),
    axis.title.x = element_text(size = 24),
    panel.grid.major.x = element_blank(),
    panel.background = element_blank(),  # removes any remaining gray fill
    strip.background = element_blank(),   # removes gray bar
    strip.text = element_blank()
  )
new_rarefactionte
ggsave("output_data/rarefactioncurvete.png",new_rarefactionte)

