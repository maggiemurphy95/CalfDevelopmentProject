# TE Script 4 - Beta-Diversity 
#############################################################################################
##############################         BETA DIVERSITY         ###############################
#############################################################################################
#############################################################################################
#NMDS on samples agglomerated at the group level####
#data prep
calf_beta_div_group_TE<- subset_samples(data_noSNP_group, sample_type=="Calf")
calf_beta_div_group_TE
calf_beta_div_group_TE.df <- as(sample_data(calf_beta_div_group_TE),"data.frame")

# Check for zeroes and ordinate 
sum(taxa_sums(calf_beta_div_group_TE)==0) # 9 not in calves by themselves 
calf_beta_div_group_TE <- prune_taxa(taxa_sums(calf_beta_div_group_TE) > 0, calf_beta_div_group_TE)#Make sure it is at 0
calf_beta_div_group_TE.css <- phyloseq_transform_css(calf_beta_div_group_TE, log = F)

calf_beta_div_group_TE.ord <- vegan::metaMDS(comm = t(otu_table(calf_beta_div_group_TE.css)), distance = "bray", try = 20, trymax = 50, autotransform = F)

plot_ordination(calf_beta_div_group_TE.css,calf_beta_div_group_TE.ord, type = "samples", color = "weaning") +
  stat_ellipse()

#Ordination Plot creation####
ordinationte<-plot_ordination(calf_beta_div_group_TE.css, calf_beta_div_group_TE.ord, type = "samples", color = "weaning") + theme_bw() +
  labs(#title = "Resistome",
    x= "NMDS1",
    y= "NMDS2") +
  geom_point(size = 3) +
  stat_ellipse(geom= "polygon", lty = 2, alpha = 0.18, aes(fill= weaning), size = 1, level = 0.99) +
  scale_colour_manual(values = cohort_palette) +
  scale_fill_manual(values = cohort_palette) +
  #coord_fixed(ratio=2.5)+
  theme(legend.position = "none",
        plot.margin = unit(c(1,1,1,1),"lines"),
        panel.border = element_rect(size = 2, colour = "black"),
        panel.grid.minor = element_blank(),
        plot.title = element_text(size = 32),
        axis.title = element_text(size = 28),
        axis.text = element_text(size = 16, colour = "black"),
        axis.ticks = element_line(size = 0.9, colour = "black"),
        aspect.ratio = 1.25)
ordinationte
ggsave("output_data/TE_Ordination.png",ordinationte)

# stats on ordination plot####
calf_beta_div_group_TE.dist <- vegdist(t(otu_table(calf_beta_div_group_TE.css)), method = "bray")
#overall adonis
adonis2(calf_beta_div_group_TE.dist~weaning, calf_beta_div_group_TE.df)
calf_beta_div_group_TE.adonis <- pairwise.adonis(calf_beta_div_group_TE.dist, calf_beta_div_group_TE.df$weaning, perm = 9999, p.adjust.m = "BH")
calf_beta_div_group_TE.adonis

#If you want to make a table
write.csv(calf_beta_div_group_TE.adonis, "calf_beta_div_group_TE.csv")

#confirm differences
calf_beta_div_group_TE.disper <- betadisper(calf_beta_div_group_TE.dist, calf_beta_div_group_TE.df$weaning)
plot(calf_beta_div_group_TE.disper, main= "Beta-Diversity Dispersion for Calves") #Make this look similar to microbiome


calf_beta_div_group_TE.permdisp <- permutest(calf_beta_div_group_TE.disper, permutations = 9999, pairwise = T)
calf_beta_div_group_TE.permdisp #NS
#If you want to make a table
write.csv(calf_beta_div_group_TE.permdisp[["pairwise"]][["permuted"]],"calf_beta_div_group_TE_permdisp.csv")
